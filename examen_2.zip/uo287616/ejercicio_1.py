# Ejercicio 1

import numpy as np
import numpy.polynomial.polynomial as pol

def vandermonde(x, k):
    k = k+1
    n = len(x)
    V = np.zeros((n,k))
    for i in range(n):
        for j in range(k):
            V[i,j] = x[i]**j
    return V

def aprox_discreta(g, x, y):
    # Calculamos su matriz de Vandermonde
    V = vandermonde(x,g)
    # Solución
    A = np.dot(V.transpose(),V)
    c = np.dot(V.transpose(),y)
    p = np.linalg.solve(A, c)
    return p

# Creamos "arrays" para los puntos y sus respectivas imágenes.
x = np.array([0, 0.25, 0.5, 1, 2])
y = np.array([0.8, 1.2, 1.5, 2.8, 7.5])

# Obtenemos los coeficientes del polinomio.
p = aprox_discreta(3, x, y)
print("Los coeficientes del polinomio son:", p)

# Con polyval obtenemos el valor en x = 2.5
sol = pol.polyval(2.5, p)
print("El valor aproximado en x = 2.5 es:", sol)

"""
Se utilizó aproximación polinómica discreta porque tenemos PUNTOS, al no
tener una función no podemos utilizar la contínua.
"""