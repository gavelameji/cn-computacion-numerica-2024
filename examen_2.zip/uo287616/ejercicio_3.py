# Ejercicio 3

import numpy as np
from scipy.integrate import quad

def simpson_comp(f,a,b,n,tol=1E-6):
    x = np.linspace(a,b,n)
    h = x[1]-x[0]
    aprox = 0
    for i in range(1,n):
        ant = aprox
        aprox += h/6 * (f(x[i-1]) + 4*f((x[i-1]+x[i])/2) + f(x[i]))
        error = abs(aprox - ant)
        if(error < tol):
            break
    return aprox

# Aproximamos la integral.
f = lambda x: (1/(2*np.pi))*np.exp(-x**2)
res = simpson_comp(f,0,1,200)
print("El valor aproximado de la integral es:",res)

"""
Justificación: Se ha utilizado Simpson porque al no ser f una
función polinómica de grado 0 ni de grado 1, es mas preciso que la del
trapecio o la del punto medio.
Se usó la compuesta porque al dividir en subintervalos es mas preciso.
"""