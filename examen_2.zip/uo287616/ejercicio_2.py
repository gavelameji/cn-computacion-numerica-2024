# Ejercicio 2

import numpy as np

def gauss_seidel(A, b, tol, maxiter=10):
    x = np.zeros_like(b)
    xant = np.zeros_like(b)
    n = b.shape[0]
    k = 0
    while k < maxiter:
        for i in range(n):
            x[i]  = b[i]
            x[i] -= np.sum(A[i,:i]*x[:i])
            x[i] -= np.sum(A[i,i+1:]*xant[i+1:])
            x[i] = x[i]/A[i,i]
        # Salimos si la diferencia es menor que la tolerancia.
        if np.linalg.norm(x-xant) < tol:
            k += 1
            break
        # Copiamos x a xant.
        xant = x.copy()
        k += 1
    return x, k

# Guardamos la matriz del sistema y el vector de términos independientes.
A = np.array([[2.,4.,5.],[6.,9.,-8.],[4.1,5.,3.],])
b = np.array([1.,1.,1.])
tol = 1.e-6

# Resolvemos
sol = gauss_seidel(A,b,tol)[0]
print("Aprox:", sol)

# Solucion real.
sol_exacta = np.linalg.solve(A,b)
print("Exacta", sol_exacta)

"""
He elegido Gauss-Seidel porque es un método iterativo para resolver sistemas
de ecuaciones lineales.

No es fiable porque las soluciones exactas difieren mucho de las aproximadas
con Gauss-Seidel. Al aumentar el numero de iteraciones, la diferencia aumenta
por lo que el método no converge a la solución del sistema.
"""

